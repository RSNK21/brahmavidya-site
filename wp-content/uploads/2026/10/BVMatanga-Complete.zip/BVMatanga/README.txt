BVMatanga — Regular & Bold
Version 1.300 · Kannada display font

CHANGES IN 1.300
Four user-supplied illustrations are embedded as scalable outline glyphs:
U+E000 Emblem; U+E001 Elephant with veena; U+E002 Matangi;
U+E003 Standing Matanga with landscape. Artwork is identical in both styles.
All 700 existing outlines and metrics remain identical to 1.210.
Open BVMatanga-Symbol-Guide.html for copy buttons and insertion instructions.
See Symbol-Key-Guide.txt for codes and BVMatanga-Website-Copy.md for web copy.
The webfonts folder includes WOFF2 files and CSS. symbols/ contains SVG/PNG art.

CHANGES IN 1.210
The vaa form now has a shortened upper neck and a flat join to the aa sign,
so it is visually distinct from maa. The correction also propagates into
dependent base forms. The approved ta, standalone va, ma/maa and stroke
weights are preserved. BVMatanga-Vaa-Correction.png shows before and after.
Only va_kannada.base and v_kannada outlines changed from version 1.200.

CHANGES IN 1.200
All ta vowel forms now share the exact body and sloping neck of the approved
1.1 revision. The separately stored i/e/base forms and the below-base pieces
have been rebuilt. The va family follows the supplied refined-va image,
including the inward left hook. The separate vu/vuu/vo forms and dependent
ma components now reuse this shared va master.
Regular remains 32 design units thick; Bold remains 46 units thick.

BVMatanga-Families-Regular.png and BVMatanga-Families-Bold.png show the full
vowel and conjunct rows. The updated revision preview shows the same rows.
In addition to the general checks, 2,355 targeted ta/va sequences per style
were shaped and rendered. Shared-core identity and unchanged standalone ta
are verified by check_families.py.

CHANGES IN 1.100
The letter ತ has been redrawn from the supplied single-letter reference,
with an open descending inner hook, broad lower bowl and longer sloping neck.
The related base and vowel variants are updated in both styles. Regular
stroke width is increased from 22 to 32 design units (about 45%) across all
nonblank glyphs, including conjunct pieces, vowel signs and punctuation.
Bold remains at 46 units, with the corrected ತ forms.

INSTALL
Windows: select both TTF files, right-click, Install (or Install for all users).
macOS: open both TTF files in Font Book and install.
Linux: copy the TTF files to ~/.local/share/fonts/ and refresh the font cache.
Replace the previously installed BVMatanga fonts with these new versions.
Restart the application after installation. Select family BVMatanga and choose
Regular or Bold. Type ordinary Unicode Kannada with your existing keyboard.

WHAT IS INCLUDED
• BVMatanga-Regular.ttf / BVMatanga-Bold.ttf — two installable, linked styles.
• glyph-images/ — 704 transparent PNG images for each style, 1,408 total.
• glyph-vectors/ — the same 1,408 glyphs as editable SVG outlines.
• glyph-sheets/ — all glyphs indexed across 11 sheets per style.
• BVMatanga-Unicode-*.png — Kannada block charts, U+0C80–U+0CFF.
• Glyph-Index.csv — mapping of glyph IDs, glyph names, codepoints and images.
• BVMatanga-Specimen.html — offline glyph browser and editable typing proof.
• BVMatanga-Preview.png — Regular/Bold text and alphabet specimen.
• Validation-Report.json — actual automated validation results.
• source/ — build scripts, centerlines, source fonts, approved reference.
• OFL.txt — required SIL Open Font License and upstream attribution.

CHARACTER COVERAGE AND SHAPING
Each style contains 704 glyphs and maps 449 Unicode characters, including 91
codepoints in the Kannada block. Coverage follows the supplied Noto Serif
Kannada source. Unmapped Unicode chart cells are labelled "not mapped".
Internal glyphs include vowel-form consonants, conjunct pieces, below-base
forms, alternate forms, punctuation, Latin support and spacing/control glyphs.
A Unicode codepoint is not the same as a font glyph. Kannada combinations are
assembled using the preserved GSUB/GPOS/GDEF shaping tables. It is not
necessary to encode every syllable as a separate Unicode character.
Blank glyph image files correspond to spaces or invisible control glyphs;
these are intentional, not missing images. Small combining forms appear as
standalone shapes in the inventory; use the typing specimen to see placement.

DESIGN AND PROVENANCE
The user-approved two-line inscription image is the design reference.
Selected consonant bodies and vowel-form variants have custom centerlines
based on its broad curves, open joins and sweeping upper strokes. These
forms propagate into dependent composites such as ma. The remaining forms
are extrapolated through smoothed, monoline Noto Serif Kannada centerlines,
with broader proportions and rounded stroke ends. Bold is built with wider
outlines from the same skeleton, not merely named Bold.

This is a working revised release of an inscription-inspired display font.
It is not a complete archaeological reconstruction: the reference contains
only a small subset of the alphabet. The other forms are interpretations.
The functional typeface includes standard Kannada vowel-length signs and
conjunct components even when the reference drawing simplifies them.
The font is derived from Noto Serif Kannada, not a wholly independent font
engine or a claim that every outline was manually drawn from the inscription.

VALIDATION
HarfBuzz shaping of consonant/vowel combinations, every supported consonant
pair and sample Kannada words is compared against the Noto source. All glyphs
are loaded and rendered with FreeType. Unicode mappings, family/style names,
weights and vertical bounds are checked. See the JSON report for counts.
Native-reader proofreading and testing in your particular design application
are recommended before publishing a long text. Regular is intended
primarily for headings, posters and large display lettering.

REBUILD
Open a terminal in source/project/. Install the packages in requirements.txt.
For the final symbol release, run python add_symbols.py,
python render.py --all, python validate.py, and python symbol_guide.py.
add_symbols.py uses the preserved approved 1.210 TTFs in previous-v1.21/.
Earlier letter-design scripts and snapshots are included for reference.
The scripts write into source/project/BVMatanga/.

SOURCES AND LICENSE
Noto Kannada project: https://github.com/notofonts/kannada
Source font: https://github.com/google/fonts/tree/main/ofl/notoserifkannada
Unicode Kannada chart: https://www.unicode.org/charts/PDF/U0C80.pdf
Noto source font copyright: The Noto Project Authors.
BVMatanga modifications: 2026. Distributed under SIL Open Font License 1.1.
Keep OFL.txt with redistributed fonts. Refer to the full license for terms.
