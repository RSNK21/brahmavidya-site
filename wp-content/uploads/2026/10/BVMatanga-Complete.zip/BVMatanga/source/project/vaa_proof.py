from pathlib import Path
from PIL import Image,ImageDraw
from render import Renderer,paste,label
R=Path(__file__).parent;O=R/'BVMatanga'
im=Image.new('RGB',(2100,1050),'#faf9f4');d=ImageDraw.Draw(im)
d.text((55,35),'BVMatanga 1.21 — vaa correction',font=label(43),fill='#24392c')
for i,t in enumerate(['va','vaa','ma','maa']):d.text((100+i*510,130),t,font=label(26),fill='#68766b')
for j,(tag,path) in enumerate([('BEFORE',R/'previous-v1.2/BVMatanga-Regular.ttf'),('CORRECTED',O/'BVMatanga-Regular.ttf')]):
 rr=Renderer(path);d.text((55,200+j*300),tag,font=label(18),fill='#647467')
 for i,t in enumerate(['ವ','ವಾ','ಮ','ಮಾ']):paste(im,rr.text(t,185),85+i*510,240+j*300)
rr=Renderer(O/'BVMatanga-Regular.ttf');paste(im,rr.text('ವಾಣಿ   ವಾದ   ವಾಸ   ಮಾತು   ಮಾಲೆ',85),65,880)
im.save(O/'BVMatanga-Vaa-Correction.png')
