"""Shared reference masters for every ta/va vowel form and dependent piece."""
import json
from pathlib import Path
from fontTools.svgLib.path import parse_path

TA_CORE='M 224 270 C 255 310 270 400 335 484 M 335 484 C 410 432 470 532 437 681 C 412 824 303 911 191 866 C 100 838 85 734 114 641 C 135 556 177 480 228 486 C 302 477 251 553 259 600 C 262 656 280 682 319 683'
TA_CAP={
 'full':'M 83 244 C 150 290 284 294 390 150',
 'base':'M 83 244 C 150 290 284 294 390 150',
 'e':'M 83 244 C 150 290 284 294 390 150 C 435 80 362 45 320 78 C 282 110 312 153 338 124',
 'i':'M 224 270 C 120 260 95 172 165 144 C 245 112 335 148 330 212 C 325 267 252 278 226 240 C 201 207 233 175 265 195',
}
VA_CORE='M 210 280 C 208 252 176 237 154 251 C 135 269 137 305 153 325 C 176 356 229 370 250 334 C 248 363 307 370 339 348 C 364 335 375 306 366 282 C 354 250 317 220 268 179'
VA_CAP={
 'full':'M 142 176 C 217 193 307 174 361 151',
 'base':'M 142 176 C 217 193 307 174 361 151',
 'e':'M 142 176 C 215 193 315 185 355 160 C 395 130 375 92 340 105 C 303 118 319 149 340 136',
 'i':'M 268 179 C 212 188 170 162 181 139 C 195 110 242 112 265 130 C 295 154 284 181 257 180 C 233 179 225 151 242 144',
}

def make_family(font,Pen,component_paths):
 def parse(s):
  p=Pen();parse_path(s,p);p._endPath();return p.paths
 def transform(pp,fn):return [[fn(x,y) for x,y in p] for p in pp]
 def shifted(pp,dx=0,dy=0):return transform(pp,lambda x,y:(x+dx,y+dy))
 def master(which,kind='full',core_only=False):
  g=font['glyf'][which+'_kannada']
  if which=='ta':
   s=TA_CORE if core_only else TA_CORE+' '+TA_CAP[kind]
   return transform(parse(s),lambda x,y:(g.xMin+8+(x-83)*(g.xMax-g.xMin-16)/367,(880-y)*739/730))
  s=VA_CORE if core_only else VA_CORE+' '+VA_CAP[kind]
  if kind=='base' and not core_only:
   s=VA_CORE.replace('C 354 250 317 220 268 179','C 354 250 334 234 318 219')+' M 142 219 C 205 219 265 219 318 219'
  return transform(parse(s),lambda x,y:(g.xMin+8+(x-140)*(g.xMax-g.xMin-16)/230,(365-y)*739/214))
 def fitted(pp,box,uniform=False):
  xs=[x for p in pp for x,y in p];ys=[y for p in pp for x,y in p];a,b,c,d=box
  if uniform:
   scale=min((c-a)/(max(xs)-min(xs)),(d-b)/(max(ys)-min(ys)))
   w=(max(xs)-min(xs))*scale;h=(max(ys)-min(ys))*scale
   a+=(c-a-w)/2;b+=(d-b-h)/2;c=a+w;d=b+h
  return transform(pp,lambda x,y:(a+(x-min(xs))*(c-a)/(max(xs)-min(xs)),b+(y-min(ys))*(d-b)/(max(ys)-min(ys))))
 mapping={}
 for k,stem in [('ta','t'),('va','v')]:
  for n,kind in [(k+'_kannada','full'),(k+'_kannada.base','base'),(stem+'i_kannada','i'),(stem+'e_kannada','e')]:mapping[n]=master(k,kind)
  n=k+'_kannada.below';g=font['glyf'][n]
  mapping[n]=fitted(master(k), (g.xMin+10,g.yMin+10,g.xMax-10,g.yMax-10),uniform=True)
 # The non-composite u/uu/o forms now reuse the exact same new va master.
 vu_tail=parse('M 359 107 C 455 -130 650 -175 790 -80 C 1010 70 950 370 820 510')
 vuu_tail=parse('M 359 107 C 450 -175 690 -190 760 100 C 800 420 920 560 1080 480 C 1290 380 1320 80 1170 -5 C 1000 -90 950 130 1065 155')
 mapping['vu_kannada']=master('va')+vu_tail
 mapping['vuu_kannada']=master('va')+vuu_tail
 mapping['vo_kannada']=master('va','e')+vuu_tail
 # Source has some ma forms flattened rather than stored as components.
 mapping['ma_kannada.base']=master('va','full')+shifted(component_paths['uMatra_kannada'],744)
 mapping['me_kannada']=master('va','e')+shifted(component_paths['uMatra_kannada'],744)
 mapping['mo_kannada']=master('va','e')+shifted(component_paths['uuMatra_kannada'],744)
 g=font['glyf']['ma_kannada.below']
 mapping['ma_kannada.below']=fitted(master('va')+shifted(component_paths['uMatra_kannada'],744),(g.xMin+10,g.yMin+10,g.xMax-10,g.yMax-10),uniform=True)
 # Rebuild precomposed below-base ta + sign combinations as two components.
 for n,part in [('t_ailength_kannada.below','ailength_kannada'),('t_rVocalicMatra_kannada.below','rVocalicMatra_kannada'),('t_ya_kannada.below','ya_kannada.below')]:
  g=font['glyf'][n];x0,x1=g.xMin+10,g.xMax-10;y0,y1=g.yMin+10,g.yMax-10
  mid=x0+(x1-x0)*.57
  mapping[n]=fitted(master('ta'),(x0,y0+30,mid-22,min(y1,y0+310)),uniform=True)+fitted(component_paths[part],(mid+10,y0,x1,y1))
 # Export master identities to allow an exact shared-core validation.
 cores={k:master(k,core_only=True) for k in ['ta','va']}
 return mapping,cores
