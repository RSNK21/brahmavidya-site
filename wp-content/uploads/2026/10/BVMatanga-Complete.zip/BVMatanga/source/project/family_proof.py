from pathlib import Path
from PIL import Image,ImageDraw
from render import Renderer,paste,label
R=Path(__file__).parent;O=R/'BVMatanga'
forms=[('', 'a'),('ಾ','aa'),('ಿ','i'),('ೀ','ii'),('ು','u'),('ೂ','uu'),('ೃ','r'),('ೄ','rr'),('ೆ','e'),('ೇ','ee'),('ೈ','ai'),('ೊ','o'),('ೋ','oo'),('ೌ','au'),('ಂ','am'),('ಃ','ah'),('್','halant'),('್ತ','+ ta'),('್ವ','+ va'),('್ಯ','+ ya'),('್ರ','+ ra'),('್ತೈ','+ tai'),('್ತೃ','+ tr'),('್ತ್ಯ','+ tya')]
for style in ['Regular','Bold']:
 rr=Renderer(O/f'BVMatanga-{style}.ttf');im=Image.new('RGB',(2400,2200),'#fbfaf5');d=ImageDraw.Draw(im)
 d.text((65,40),'BVMatanga 1.21 / '+style,font=label(50),fill='#233b2c')
 d.text((65,112),'Complete ta and va families — one revised body for every vowel form',font=label(27),fill='#637366')
 for col,c in enumerate(['ತ','ವ']):
  part=rr.text(c,340);paste(im,part,230+col*1150,220)
 for j,c in enumerate(['ತ','ವ']):
  ytop=680+j*640
  d.text((65,ytop-45),('TA FAMILY' if j==0 else 'VA FAMILY'),font=label(26),fill='#4c6556')
  for i,(v,tag) in enumerate(forms):
   x=55+(i%8)*287;y=ytop+(i//8)*185
   d.rounded_rectangle((x,y,x+277,y+170),12,fill='white',outline='#dce4dc')
   part=rr.text(c+v,83)
   if part.width>245 or part.height>124:part.thumbnail((245,124),Image.Resampling.LANCZOS)
   paste(im,part,x+(277-part.width)//2,y+15)
   d.text((x+15,y+140),tag,font=label(18),fill='#7a857e')
 paste(im,rr.text('ಮತಂಗೇಶ್ವರ   ದೇವರದಿಡ್ಡಿ   ತತ್ವ   ವಾಣಿ',65),70,2010)
 d.text((65,2140),'Regular and Bold retain their approved stroke weights. Full Unicode shaping is preserved.',font=label(21),fill='#637366')
 im.save(O/f'BVMatanga-Families-{style}.png')
 if style=='Regular':im.save(O/'BVMatanga-Revision-Preview.png')
