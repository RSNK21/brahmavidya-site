from pathlib import Path
import json, shutil
import numpy as np
import potrace
from PIL import Image
from fontTools.ttLib import TTFont
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.recordingPen import RecordingPen

ROOT=Path(__file__).parent
OUT=ROOT/'BVMatanga'
UPLOAD=ROOT.parent/'upload'
if not UPLOAD.is_dir():UPLOAD=ROOT/'source/symbol-reference'
SPECS=[
 (0xE000,'bv_emblem','Emblem','download.png'),
 (0xE001,'bv_elephant_veena','Elephant with veena',"matanga's veena line drawing.png"),
 (0xE002,'bv_matangi','Matangi','matangi linedrawing.jpg'),
 (0xE003,'bv_standing_matanga','Standing Matanga with landscape','standing matanga line drawing.png'),
]

def trace(filename):
 im=Image.open(UPLOAD/filename).convert('RGBA')
 bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im)
 grey=bg.convert('L');mask=np.array(grey)<175
 ys,xs=np.where(mask);box=(xs.min(),ys.min(),xs.max()+1,ys.max()+1)
 grey=grey.crop(box)
 if grey.height<500:grey=grey.resize((grey.width*4,grey.height*4),Image.Resampling.LANCZOS)
 mask=np.array(grey)<175
 # Potrace uses zero for ink. Retain fine interior details and artwork backgrounds.
 paths=potrace.Bitmap(~np.pad(mask,2,constant_values=False)).trace(turdsize=1,alphamax=1,opticurve=True,opttolerance=0.7)
 h,w=mask.shape;scale=1000/h
 rec=RecordingPen()
 def pt(p):return (50+(p.x-2)*scale,1000-(p.y-2)*scale)
 for curve in paths:
  rec.moveTo(pt(curve.start_point))
  for seg in curve:
   if seg.is_corner:
    rec.lineTo(pt(seg.c));rec.lineTo(pt(seg.end_point))
   else:rec.curveTo(pt(seg.c1),pt(seg.c2),pt(seg.end_point))
  rec.closePath()
 pen=TTGlyphPen(None);rec.replay(Cu2QuPen(pen,max_err=0.9,reverse_direction=False))
 glyph=pen.glyph(dropImpliedOnCurves=True);glyph.recalcBounds(None)
 return glyph,round(w*scale+100)

def main():
 (OUT/'symbols').mkdir(exist_ok=True)
 (OUT/'source/symbol-reference').mkdir(exist_ok=True)
 data=[];glyphs={}
 for cp,name,title,filename in SPECS:
  g,aw=trace(filename);glyphs[name]=(g,aw)
  print(title,len(g.coordinates),'points',flush=True)
  data.append({'codepoint':f'U+{cp:04X}','character':chr(cp),'glyph_name':name,'title':title,'source':filename,'advance_width':aw,'points':len(g.coordinates)})
  shutil.copy2(UPLOAD/filename,OUT/'source/symbol-reference'/filename)
 for style in ['Regular','Bold']:
  f=TTFont(ROOT/'previous-v1.21'/f'BVMatanga-{style}.ttf')
  order=f.getGlyphOrder()+[x[1] for x in SPECS];f.setGlyphOrder(order)
  for cp,name,title,filename in SPECS:
   g,aw=glyphs[name];f['glyf'][name]=g;f['hmtx'][name]=(aw,g.xMin)
   for table in f['cmap'].tables:
    if table.isUnicode() and table.format in (4,12):table.cmap[cp]=name
  f['maxp'].numGlyphs=len(order);f['head'].fontRevision=1.3
  for nid,value in [(3,f'BVMatanga:1.300:{style}'),(5,'Version 1.300')]:
   for p,e,l in [(3,1,0x409),(1,0,0)]:f['name'].setName(value,nid,p,e,l)
  f['OS/2'].ulUnicodeRange2 |= 1 << (60-32)
  f['OS/2'].usLastCharIndex=max(f.getBestCmap())
  f.save(OUT/f'BVMatanga-{style}.ttf')
  f.flavor='woff2';(OUT/'webfonts').mkdir(exist_ok=True);f.save(OUT/'webfonts'/f'BVMatanga-{style}.woff2')
 f=TTFont(OUT/'BVMatanga-Regular.ttf');gs=f.getGlyphSet()
 for cp,name,title,filename in SPECS:
  pen=SVGPathPen(gs);gs[name].draw(pen);g=f['glyf'][name]
  svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{g.xMin-10} {-g.yMax-10} {g.xMax-g.xMin+20} {g.yMax-g.yMin+20}"><title>{title}</title><path transform="scale(1,-1)" d="{pen.getCommands()}" fill="currentColor"/></svg>'
  (OUT/'symbols'/f'{name}.svg').write_text(svg)
 (OUT/'Symbol-Map.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
