from pathlib import Path
import json,unicodedata,hashlib
from fontTools.ttLib import TTFont
import uharfbuzz as hb
import freetype
R=Path(__file__).parent;O=R/'BVMatanga'
source=TTFont(R/'source/NotoThin.ttf');cmap=source.getBestCmap();cons=[chr(c) for c in range(0xc95,0xcba) if c in cmap];vowels=['','ಾ','ಿ','ೀ','ು','ೂ','ೃ','ೄ','ೆ','ೇ','ೈ','ೊ','ೋ','ೌ','ಂ','ಃ','್']
samples=[c+v for c in cons for v in vowels]+[a+'್'+b for a in cons for b in cons]+['ಮತಂಗೇಶ್ವರ','ದೇವರದಿಡ್ಡಿ','ಕನ್ನಡ','ಶ್ರೀಶಾರದಾಂಬಾ ದೇವಾಲಯ','ಶಂಕರ ಮಠ','ಪಾರ್ವತಿಯ ತಪಸ್ಸು','ಕ್ಷೇತ್ರ','ಜ್ಞಾನ','ಸ್ತ್ರೀ','ಸ್ವಾತಂತ್ರ್ಯ','ದೃಷ್ಟಿ','ಸಂಸ್ಕೃತ','ಕೃಪೆ','ಕ್ಕ್ರ್ಯ','ರ್ತ್ರ','ರಾಷ್ಟ್ರ','೦೧೨೩೪೫೬೭೮೯']
def font(p):
 f=hb.Font(hb.Face(p.read_bytes()));f.scale=(1000,1000);hb.ot_font_set_funcs(f);return f
def shape(f,s):
 b=hb.Buffer();b.add_str(s);b.guess_segment_properties();hb.shape(f,b);return [(i.codepoint,p.x_advance,p.y_advance,p.x_offset,p.y_offset) for i,p in zip(b.glyph_infos,b.glyph_positions)]
base=font(R/'source/NotoThin.ttf');report={'release':'1.300','family':'BVMatanga','reference':'User-approved Reconstructed Kannada rock inscription(1).png','tests':{}}
for style in ['Regular','Bold']:
 p=O/f'BVMatanga-{style}.ttf';tt=TTFont(p,checkChecksums=2);f=font(p);face=freetype.Face(str(p));face.set_char_size(64*64)
 assert {c:n for c,n in tt.getBestCmap().items() if c not in range(0xE000,0xE004)}==cmap
 assert len(tt.getGlyphOrder())==704
 assert tt['name'].getDebugName(1)=='BVMatanga'
 assert tt['OS/2'].usWeightClass==(400 if style=='Regular' else 700)
 for s in samples:
  a=shape(base,s);b=shape(f,s)
  assert [v[0] for v in a]==[v[0] for v in b],s
  assert not any(v[0]==0 for v in b),s
 empty=[]
 for i,n in enumerate(tt.getGlyphOrder()):
  face.load_glyph(i,freetype.FT_LOAD_RENDER)
  if not tt['glyf'][n].numberOfContours:
   empty.append(n)
   assert source['glyf'][n].numberOfContours==0,('Unexpected blank glyph',n)
  g=tt['glyf'][n]
  if g.numberOfContours:
   assert g.yMax<=tt['OS/2'].usWinAscent,(n,g.yMax)
   assert -g.yMin<=tt['OS/2'].usWinDescent,(n,g.yMin)
 report['tests'][style]={'glyph_count':704,'mapped_codepoints':len(tt.getBestCmap()),'kannada_block_codepoints':len([c for c in cmap if 0xc80<=c<0xd00]),'shaping_cases_passed':len(samples),'all_glyphs_rasterized':True,'same_shaping_glyph_sequences_as_source':True,'empty_glyphs':empty,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size_bytes':p.stat().st_size}
assert (O/'BVMatanga-Regular.ttf').read_bytes()!=(O/'BVMatanga-Bold.ttf').read_bytes()
report['limitations']=['Automated HarfBuzz and FreeType validation, not independent native-reader proofreading.','Letters absent from the reference are extrapolated from Noto Serif Kannada skeletons, not historical attestations.','Display-font first release; cross-application and small-size optical QA remain advisable.']
(O/'Validation-Report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
