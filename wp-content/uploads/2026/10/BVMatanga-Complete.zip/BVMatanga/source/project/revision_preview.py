from pathlib import Path
from render import Renderer,paste,label
from PIL import Image,ImageDraw
r=Path(__file__).parent;o=r/'BVMatanga'
im=Image.new('RGB',(1800,1200),'white');d=ImageDraw.Draw(im)
d.text((60,35),'BVMatanga 1.1 — revised ta (U+0CA4)',font=label(34),fill='#273c31')
for i,(sty,path) in enumerate([('PREVIOUS REGULAR',r/'previous-v1/BVMatanga-Regular.ttf'),('UPDATED REGULAR',o/'BVMatanga-Regular.ttf'),('UPDATED BOLD',o/'BVMatanga-Bold.ttf')]):
 rr=Renderer(path);d.text((60+i*580,110),sty,font=label(22),fill='#647267');paste(im,rr.text('ತ',500),60+i*580,170)
rr=Renderer(o/'BVMatanga-Regular.ttf')
paste(im,rr.text('ತ ತಾ ತಿ ತೀ ತು ತೂ ತೆ ತೇ ತೈ ತೊ ತೋ ತೌ ತ್ತ ತ್ರ',65),60,700)
paste(im,rr.text('ಮತಂಗೇಶ್ವರ  ದೇವರದಿಡ್ಡಿ',85),60,880)
d.text((60,1120),'Regular strokes increased from 22 to 32 design units (about 45%).',font=label(24),fill='#647267')
im.save(o/'BVMatanga-Revision-Preview.png')
