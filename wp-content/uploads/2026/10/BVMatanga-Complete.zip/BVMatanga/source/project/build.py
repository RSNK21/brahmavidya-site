from pathlib import Path
import math,json,csv,re,copy
import numpy as np
import freetype
from fontTools.ttLib import TTFont
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.basePen import BasePen
from fontTools.svgLib.path import parse_path
from skimage.morphology import skeletonize
from shapely.geometry import LineString,Point,Polygon
from shapely.ops import unary_union
from shapely.geometry.polygon import orient
from scipy.interpolate import splprep,splev

ROOT=Path(__file__).parent; OUT=ROOT/'BVMatanga';OUT.mkdir(exist_ok=True)
BASE=ROOT/'source/NotoThin.ttf'
font=TTFont(BASE);order=font.getGlyphOrder();face=freetype.Face(str(BASE));SIZE=600;face.set_char_size(SIZE*64)
SCALE=font['head'].unitsPerEm/SIZE
# Original centerline drawings developed from the user's approved reference.
# Coordinates: x=0..1000 across the glyph body; y=0..1000 from body top to baseline.
body={
'va':'M 440 130 C 170 0 -10 270 15 590 C 30 900 390 1100 485 825 C 480 1040 870 1060 970 800 C 1110 480 790 130 550 -115',
'da':'M 400 55 C 120 -100 -40 300 15 610 C 70 1010 410 1080 485 820 C 490 1080 900 1060 975 740 C 1080 380 810 50 550 -115',
'ra':'M 950 410 C 950 80 740 -80 490 -80 C 160 -80 -35 130 10 530 C 45 910 290 1030 560 1010 C 890 1000 1040 810 1000 570 C 1000 510 980 450 950 410',
'ga':'M 65 950 C -10 780 -25 390 190 130 C 350 -60 550 -40 710 100 M 540 -115 C 580 0 790 90 900 390 C 1030 670 1035 850 970 970',
'ta':'M 690 0 C 910 -100 1060 160 965 500 C 865 855 565 1080 260 965 C 5 875 -50 565 55 290 C 135 70 280 -50 410 15 C 550 90 365 325 485 475 C 530 530 590 545 640 540',
'sha':'M 400 165 C 170 260 -50 80 85 15 C 260 -80 690 -30 865 160 C 1100 410 1030 710 760 890 C 520 1055 210 1020 75 840 C -120 580 125 435 320 530 C 455 600 535 745 625 850',
'dda':'M 395 115 C 120 10 -35 350 20 670 C 80 1020 420 1070 480 830 C 535 1095 1000 1020 985 690 C 980 495 910 340 760 280 C 890 30 620 -90 395 115',
}
head='M 10 -135 C 280 -55 680 -90 965 -285'
etop='M 10 -145 C 300 -40 800 -70 930 -365 C 1070 -710 750 -970 450 -835 C 195 -710 395 -445 530 -610'
itop='M 45 90 C -135 -130 5 -610 385 -555 C 740 -490 1030 -215 950 260'
# For the photographed di and ddi the i sign is a separate, open curl.
iref='M 40 50 C -100 -140 -50 -450 245 -540 C 540 -660 990 -480 1000 -125 C 1010 45 940 190 890 280'
class FlatPen(BasePen):
 def __init__(self):super().__init__(None);self.paths=[];self.cur=[]
 def _moveTo(self,p):
  if self.cur:self.paths.append(self.cur)
  self.cur=[p]
 def _lineTo(self,p):self.cur.append(p)
 def _curveToOne(self,a,b,c):
  p=self.cur[-1]
  for t in np.linspace(0,1,40)[1:]:self.cur.append(tuple((1-t)**3*p[i]+3*(1-t)**2*t*a[i]+3*(1-t)*t*t*b[i]+t**3*c[i] for i in (0,1)))
 def _qCurveToOne(self,a,b):
  p=self.cur[-1]
  for t in np.linspace(0,1,30)[1:]:self.cur.append(tuple((1-t)**2*p[i]+2*(1-t)*t*a[i]+t*t*b[i] for i in (0,1)))
 def _closePath(self):self.cur.append(self.cur[0]);self._endPath()
 def _endPath(self):
  if self.cur:self.paths.append(self.cur);self.cur=[]

from family_revision import make_family
_component_paths=json.loads((ROOT/'centerlines.json').read_text())
FAMILY_FORMS,FAMILY_CORES=make_family(font,FlatPen,_component_paths)

def custom(n):
 if n in FAMILY_FORMS:return FAMILY_FORMS[n]
 kind=None;key=None
 for k in body:
  if n==k+'_kannada':key=k;kind='full'
  if n==k+'_kannada.base':key=k;kind='base'
  stem={'ga':'g','da':'d','dda':'dd','va':'v','ra':'r','ta':'t','sha':'sh'}[k]
  if n==stem+'e_kannada':key=k;kind='e'
  if n==stem+'i_kannada':key=k;kind='i'
 if n=='anusvara_kannada':
  s='M 500 0 C 1180 0 1180 1040 500 1040 C -180 1040 -180 0 500 0'
  key='anusvara';kind='ring'
 if key is None:return None
 if key=='ta' and kind=='full':
  # Direct centerline redraw of the user's letter-ta reference: open inward
  # descending hook, large lower bowl, long sloping neck and rising cap.
  pp=FlatPen()
  parse_path('M 83 244 C 150 290 284 294 390 150 M 224 270 C 255 310 270 400 335 484 M 335 484 C 410 432 470 532 437 681 C 412 824 303 911 191 866 C 100 838 85 734 114 641 C 135 556 177 480 228 486 C 302 477 251 553 259 600 C 262 656 280 682 319 683',pp)
  pp._endPath();gg=font['glyf'][n]
  return [[(gg.xMin+8+(x-83)*(gg.xMax-gg.xMin-16)/367,(880-y)*739/730) for x,y in line] for line in pp.paths]

 if kind!='ring':
  s=body[key]
  if key=='ta':
   s+=' M 380 -110 C 490 -80 510 -35 690 0'
  if kind=='full':s+=' '+head
  if kind=='e':s+=' '+etop
  if kind=='i':s+=' '+iref
  if key=='ra':s+=' M 540 -85 L 540 -145'
 pen=FlatPen();parse_path(s,pen);pen._endPath()
 g=font['glyf'][n];x0=g.xMin+8;x1=g.xMax-8
 # All body variants retain the parent's horizontal metrics and attachment space.
 if kind in ('e','i','base'):
  gg=font['glyf'][key+'_kannada'];x0=gg.xMin+8;x1=gg.xMax-8
 arr=[]
 for p in pen.paths:
  arr.append([(x0+x*(x1-x0)/1000,500-y*.5) for x,y in p])
 return arr

def raster_paths(gid):
 face.load_glyph(gid,freetype.FT_LOAD_RENDER|freetype.FT_LOAD_NO_HINTING|freetype.FT_LOAD_NO_AUTOHINT)
 b=face.glyph.bitmap
 if not b.width or not b.rows:return []
 a=np.array(b.buffer,dtype=np.uint8).reshape(b.rows,b.pitch)[:,:b.width]>96
 sk=skeletonize(np.pad(a,2));pts=set(zip(*np.where(sk)))
 adj={p:[] for p in pts}
 for y,x in pts:
  for dy,dx in ((-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)):
   q=(y+dy,x+dx)
   if q in pts:
    if dy and dx and ((y+dy,x) in pts or (y,x+dx) in pts):continue
    adj[(y,x)].append(q)
 used=set();paths=[]
 def follow(p,q):
  z=[p,q];used.add(frozenset((p,q)))
  while len(adj[q])==2:
   r=adj[q][0] if adj[q][1]==p else adj[q][1]
   if frozenset((q,r)) in used:break
   z.append(r);used.add(frozenset((q,r)));p,q=q,r
  return z
 for p,neigh in adj.items():
  if len(neigh)!=2:
   if len(neigh)==0:paths.append([p])
   for q in neigh:
    if frozenset((p,q)) not in used:paths.append(follow(p,q))
 for p,neigh in adj.items():
  for q in neigh:
   if frozenset((p,q)) not in used:paths.append(follow(p,q))
 out=[]
 for z in paths:
  # Trim tiny terminal serif spurs; keep isolated dots and all substantial marks.
  if len(z)>1 and len(z)*SCALE<17 and ((len(adj[z[0]])==1 and len(adj[z[-1]])>2) or (len(adj[z[-1]])==1 and len(adj[z[0]])>2)) and len(paths)>1:continue
  xy=np.array([((x-2+face.glyph.bitmap_left)*SCALE,(face.glyph.bitmap_top-y+2)*SCALE) for y,x in z])
  if len(xy)>4:
   simple=np.array(LineString(xy).simplify(1.7).coords)
   if len(simple)>3:
    try:
     tck,u=splprep(simple.T,s=len(simple)*1.1,per=bool(np.linalg.norm(simple[0]-simple[-1])<3))
     sm=np.array(splev(np.linspace(0,1,max(10,int(LineString(simple).length/3))),tck)).T
     sm[0]=xy[0];sm[-1]=xy[-1];xy=sm
    except ValueError:xy=simple
  out.append(xy.tolist())
 return out

cache=ROOT/'centerlines.json'
if cache.exists():paths=json.loads(cache.read_text())
else:
 paths={}
 for i,n in enumerate(order):
  paths[n]=custom(n) or raster_paths(i)
  if i%100==0:print('Centerlines',i,'/',len(order),flush=True)
 cache.write_text(json.dumps(paths))
# Regenerate hand-authored overrides when this script is refined.
for n in order:
 c=custom(n)
 if c is not None:paths[n]=c
cache.write_text(json.dumps(paths))
# Propagate reference-based designs into dependent composite glyphs.
resolved={}
def resolve(n):
 if n in resolved:return resolved[n]
 g=font['glyf'][n]
 if g.isComposite() and custom(n) is None:
  pp=[]
  for component in g.components:
   cn,tr=component.getComponentInfo();xx,xy,yx,yy,dx,dy=tr
   pp += [[(x*xx+y*yx+dx,x*xy+y*yy+dy) for x,y in line] for line in resolve(cn)]
  resolved[n]=pp
 else:resolved[n]=paths[n]
 return resolved[n]
for n in order:resolve(n)
paths=resolved
(ROOT/'resolved-centerlines.json').write_text(json.dumps(paths))
(ROOT/'family-cores.json').write_text(json.dumps(FAMILY_CORES))
X=1.14

def glyph_for(pp,radius):
 geoms=[]
 for p in pp:
  q=[(x*X,y) for x,y in p]
  if len(q)==1:geoms.append(Point(q[0]).buffer(radius,quad_segs=5))
  elif len(q)>1:geoms.append(LineString(q).buffer(radius,quad_segs=5,cap_style='round',join_style='round'))
 pen=TTGlyphPen(None)
 if not geoms:return pen.glyph()
 shape=unary_union(geoms).buffer(0).simplify(.7,preserve_topology=True)
 polygons=[shape] if shape.geom_type=='Polygon' else list(shape.geoms)
 for poly in polygons:
  if poly.geom_type!='Polygon':continue
  poly=orient(poly,sign=-1)
  for ring in [poly.exterior]+list(poly.interiors):
   coords=[tuple(round(v) for v in p) for p in ring.coords[:-1]]
   coords=[p for i,p in enumerate(coords) if i==0 or p!=coords[i-1]]
   if len(coords)<3:continue
   pen.moveTo(coords[0])
   for p in coords[1:]:pen.lineTo(p)
   pen.closePath()
 return pen.glyph()

def scale_ot(obj,seen=None):
 if seen is None:seen=set()
 if id(obj) in seen:return
 seen.add(id(obj))
 if isinstance(obj,(list,tuple)):
  for item in obj:scale_ot(item,seen)
 elif hasattr(obj,'__dict__'):
  for k,v in list(obj.__dict__.items()):
   if k in ('XCoordinate','XPlacement','XAdvance') and isinstance(v,(int,float)):setattr(obj,k,round(v*X))
   elif not isinstance(v,(int,float,str,bytes,type(None))):scale_ot(v,seen)

for style,radius,weight in [('Regular',16,400),('Bold',23,700)]:
 f=TTFont(BASE)
 for tag in ['prep','fpgm','cvt ','gasp','DSIG','STAT']:
  if tag in f:del f[tag]
 for i,n in enumerate(order):
  g=glyph_for(paths[n],radius);f['glyf'][n]=g
  g.recalcBounds(f['glyf'])
  aw,lsb=f['hmtx'][n];f['hmtx'][n]=(round(aw*X),g.xMin if g.numberOfContours else round(lsb*X))
 for tag in ['GPOS','GDEF']:
  if tag in f:scale_ot(f[tag].table)
 name=f['name']
 for rec in list(name.names):
  if rec.nameID not in (0,13,14):name.names.remove(rec)
 texts={1:'BVMatanga',2:style,3:f'BVMatanga 1.210 {style}',4:f'BVMatanga {style}',5:'Version 1.210',6:f'BVMatanga-{style}',7:'',8:'BVMatanga project',9:'BVMatanga lettering; based on Noto Kannada shaping and extrapolated glyph structures',10:'Inscription-inspired Kannada display typeface. Reference-derived forms and extrapolated monoline forms. Derived from Noto Serif Kannada under SIL OFL 1.1.',16:'BVMatanga',17:style}
 for nid,txt in texts.items():
  name.setName(txt,nid,3,1,0x409)
  name.setName(txt,nid,1,0,0)
 old=name.getDebugName(0) or ''
 name.setName(old+' BVMatanga modifications 2026.',0,3,1,0x409)
 f['OS/2'].usWeightClass=weight;f['OS/2'].fsSelection=(1<<7)|((1<<5) if style=='Bold' else (1<<6))
 f['head'].macStyle=1 if style=='Bold' else 0;f['head'].fontRevision=1.21
 f['post'].isFixedPitch=0;f['post'].italicAngle=0
 f['hhea'].advanceWidthMax=max(v[0] for v in f['hmtx'].metrics.values())
 f['OS/2'].xAvgCharWidth=round(f['OS/2'].xAvgCharWidth*X)
 # Room for tall stacked vowel signs and below-base conjuncts.
 f['hhea'].ascent=1350;f['hhea'].descent=-750;f['hhea'].lineGap=0
 f['OS/2'].sTypoAscender=1350;f['OS/2'].sTypoDescender=-750;f['OS/2'].sTypoLineGap=0
 f['OS/2'].usWinAscent=1600;f['OS/2'].usWinDescent=900
 f.save(OUT/f'BVMatanga-{style}.ttf')
 print('Saved',style,len(order),'glyphs',flush=True)
