from pathlib import Path
import json,csv,math,html,unicodedata
import freetype,uharfbuzz as hb
from PIL import Image,ImageDraw,ImageFont
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
ROOT=Path(__file__).parent;OUT=ROOT/'BVMatanga'
LABEL='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
label=lambda size:ImageFont.truetype(LABEL,size)
class Renderer:
 def __init__(self,path):
  self.path=path;self.font=TTFont(path);self.face=freetype.Face(str(path));self.hbf=hb.Font(hb.Face(path.read_bytes()));self.hbf.scale=(1000,1000);hb.ot_font_set_funcs(self.hbf)
 def shape(self,text):
  b=hb.Buffer();b.add_str(text);b.guess_segment_properties();hb.shape(self.hbf,b);return list(zip(b.glyph_infos,b.glyph_positions))
 def text(self,text,size,color=(25,28,27)):
  shaped=self.shape(text);self.face.set_char_size(size*64);scale=size/1000;x=0;y=0;items=[];xmin=0;ymin=0;xmax=0;ymax=0
  for info,pos in shaped:
   self.face.load_glyph(info.codepoint,freetype.FT_LOAD_RENDER|freetype.FT_LOAD_NO_HINTING)
   g=self.face.glyph;b=g.bitmap
   px=round((x+pos.x_offset)*scale)+g.bitmap_left;py=round(-(y+pos.y_offset)*scale)-g.bitmap_top
   if b.width and b.rows:
    mask=Image.frombytes('L',(b.width,b.rows),bytes(b.buffer));items.append((px,py,mask));xmin=min(xmin,px);ymin=min(ymin,py);xmax=max(xmax,px+b.width);ymax=max(ymax,py+b.rows)
   x+=pos.x_advance;y+=pos.y_advance
  xmax=max(xmax,round(x*scale));im=Image.new('RGBA',(max(1,xmax-xmin+8),max(1,ymax-ymin+8)))
  for px,py,m in items:im.paste(color+(255,),(px-xmin+4,py-ymin+4),m)
  return im
 def glyph(self,gid,size=512):
  self.face.set_char_size(330*64);self.face.load_glyph(gid,freetype.FT_LOAD_RENDER|freetype.FT_LOAD_NO_HINTING);b=self.face.glyph.bitmap
  im=Image.new('RGBA',(size,size),(255,255,255,0))
  if b.width and b.rows:
   m=Image.frombytes('L',(b.width,b.rows),bytes(b.buffer));m.thumbnail((size-64,size-64),Image.Resampling.LANCZOS);im.paste((0,0,0,255),((size-m.width)//2,(size-m.height)//2),m)
  return im

def paste(im,part,x,y):im.paste(part,(x,y),part)

def specimen():
 im=Image.new('RGB',(2000,1750),'#f8f5ed');d=ImageDraw.Draw(im)
 d.text((90,70),'BVMatanga',font=label(76),fill='#24362d');d.text((95,165),'KANNADA  /  REGULAR + BOLD  /  VERSION 1.300',font=label(23),fill='#647267')
 samples=[('REGULAR','ಮತಂಗೇಶ್ವರ',105),('','ದೇವರದಿಡ್ಡಿ',105),('VOWELS','ಅ ಆ ಇ ಈ ಉ ಊ ಋ ೠ ಎ ಏ ಐ ಒ ಓ ಔ',57),('CONSONANTS','ಕ ಖ ಗ ಘ ಙ   ಚ ಛ ಜ ಝ ಞ   ಟ ಠ ಡ ಢ ಣ',49),('','ತ ಥ ದ ಧ ನ   ಪ ಫ ಬ ಭ ಮ   ಯ ರ ಲ ವ ಶ ಷ ಸ ಹ ಳ',49),('VOWEL SIGNS','ಕ ಕಾ ಕಿ ಕೀ ಕು ಕೂ ಕೃ ಕೆ ಕೇ ಕೈ ಕೊ ಕೋ ಕೌ ಕಂ ಕಃ',51),('CONJUNCTS','ಕ್ಕ ಗ್ಗ ತ್ತ ನ್ನ ದ್ದ ಡ್ಡ ಕ್ಷ ಜ್ಞ ಶ್ರ ಶ್ರೀ ಶ್ವ ರ್ಕ ಕ್ರ',53),('DIGITS','೦ ೧ ೨ ೩ ೪ ೫ ೬ ೭ ೮ ೯',57)]
 y=260;r=Renderer(OUT/'BVMatanga-Regular.ttf')
 for tag,txt,size in samples:
  if tag:d.text((95,y+8),tag,font=label(18),fill='#6b776e')
  part=r.text(txt,size)
  if part.width>1550:part.thumbnail((1550,190),Image.Resampling.LANCZOS)
  paste(im,part,355,y);y+=max(105,part.height+30)
 d.line((90,y+10,1910,y+10),fill='#c2cbc3',width=2);y+=45
 d.text((95,y+10),'BOLD',font=label(20),fill='#6b776e');b=Renderer(OUT/'BVMatanga-Bold.ttf');paste(im,b.text('ಮತಂಗೇಶ್ವರ',110),355,y)
 y+=180;paste(im,b.text('ಕನ್ನಡ ಅಕ್ಷರಗಳ ಹೊಸ ರೂಪ',67),355,y)
 d.text((95,1655),'Reference-derived forms + extrapolated Kannada glyphs. Intended for display typography.',font=label(21),fill='#657168')
 im.save(OUT/'BVMatanga-Preview.png')

def assets():
 regular=TTFont(OUT/'BVMatanga-Regular.ttf');order=regular.getGlyphOrder();cmap=regular.getBestCmap();rev={}
 for cp,n in cmap.items():rev.setdefault(n,[]).append(cp)
 rows=[]
 for style in ['Regular','Bold']:
  r=Renderer(OUT/f'BVMatanga-{style}.ttf');gs=r.font.getGlyphSet();folder=OUT/'glyph-images'/style;folder.mkdir(parents=True,exist_ok=True);svgdir=OUT/'glyph-vectors'/style;svgdir.mkdir(parents=True,exist_ok=True)
  for i,n in enumerate(order):
   stem=f'{i:03d}_{n}';r.glyph(i).save(folder/(stem+'.png'))
   g=r.font['glyf'][n];pen=SVGPathPen(gs);gs[n].draw(pen);data=pen.getCommands()
   if g.numberOfContours:
    x0,y0,x1,y1=g.xMin-30,g.yMin-30,g.xMax+30,g.yMax+30
   else:x0,y0,x1,y1=0,0,500,500
   svgdir.joinpath(stem+'.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{x0} {-y1} {x1-x0} {y1-y0}"><path transform="scale(1,-1)" d="{data}" fill="black"/></svg>')
   if style=='Regular':rows.append([i,n,' '.join(f'U+{cp:04X}' for cp in rev.get(n,[])),' | '.join(unicodedata.name(chr(cp),'UNNAMED') for cp in rev.get(n,[])),f'glyph-images/Regular/{stem}.png',f'glyph-images/Bold/{stem}.png'])
  # Complete direct-Unicode Kannada chart, including explicit unassigned cells.
  chart=Image.new('RGB',(1600,2470),'white');d=ImageDraw.Draw(chart);d.text((50,30),f'BVMatanga {style} — Kannada Unicode chart',font=label(30),fill='#17291f')
  for cp in range(0xc80,0xd00):
   k=cp-0xc80;x=k%8*200;y=100+k//8*145;d.rectangle((x,y,x+199,y+144),outline='#d9dedb')
   d.text((x+12,y+9),f'U+{cp:04X}',font=label(17),fill='#647267')
   n=cmap.get(cp)
   if n:
    p=r.glyph(r.font.getGlyphID(n),130);paste(chart,p,x+35,y+19)
   else:d.text((x+20,y+70),'not mapped',font=label(15),fill='#a5aaa7')
  chart.save(OUT/f'BVMatanga-Unicode-{style}.png')
  # All OpenType glyphs, including internal base forms and below-base pieces.
  sheets=OUT/'glyph-sheets'/style;sheets.mkdir(parents=True,exist_ok=True)
  for start in range(0,len(order),70):
   sh=Image.new('RGB',(1800,1900),'white');dd=ImageDraw.Draw(sh);dd.text((30,20),f'BVMatanga {style} / glyphs {start}–{min(start+69,len(order)-1)}',font=label(28),fill='black')
   for k,n in enumerate(order[start:start+70]):
    x=(k%7)*255;y=80+(k//7)*180;part=r.glyph(start+k,140);paste(sh,part,x+55,y);dd.text((x+6,y+145),f'{start+k:03d} {n}',font=label(12),fill='#45534b')
   sh.save(sheets/f'{start:03d}-{min(start+69,len(order)-1):03d}.png')
  print('Rendered all assets',style,flush=True)
 with (OUT/'Glyph-Index.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['glyph_id','glyph_name','unicode','unicode_name','regular_image','bold_image']);w.writerows(rows)
 # Offline browsing and typing proof with actual bundled fonts.
 cards=''.join(f'<article><img loading="lazy" src="{html.escape(row[4])}"><small>{row[0]:03d} · {html.escape(row[1])}<br>{row[2]}</small></article>' for row in rows)
 (OUT/'BVMatanga-Specimen.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><title>BVMatanga — glyph library</title><style>@font-face{font-family:BVMatanga;src:url('BVMatanga-Regular.ttf')}@font-face{font-family:BVMatanga;src:url('BVMatanga-Bold.ttf');font-weight:700}body{margin:40px;background:#faf8f1;color:#24382b;font-family:system-ui}h1{font-size:48px}.sample{font-family:BVMatanga;font-size:68px;line-height:2;overflow-wrap:anywhere;border:1px solid #bac8bd;background:white;padding:20px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px}article{background:white;padding:10px;overflow:hidden}img{width:100%}small{font-size:11px}button{padding:10px;margin:12px}</style><h1>BVMatanga</h1><p>Regular & Bold · 704 glyphs per style · editable Kannada proof below</p><div class="sample" contenteditable="true">ಮತಂಗೇಶ್ವರ<br>ದೇವರದಿಡ್ಡಿ<br>ಕನ್ನಡ ಅಕ್ಷರಗಳ ಹೊಸ ರೂಪ</div><button onclick="document.querySelector('.sample').style.fontWeight='400'">Regular</button><button onclick="document.querySelector('.sample').style.fontWeight='700'">Bold</button><p>Reference-derived letters and extrapolated forms; based on Noto Serif Kannada shaping. This is a display-font release.</p><h2>Complete glyph inventory</h2><div class="grid">'''+cards+'</div></html>')

if __name__=='__main__':
 specimen()
 if '--all' in __import__('sys').argv:assets()
