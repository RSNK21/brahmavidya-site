from pathlib import Path
import json
from PIL import ImageChops
from render import Renderer
from fontTools.ttLib import TTFont
R=Path(__file__).parent;O=R/'BVMatanga'
paths=json.loads((R/'resolved-centerlines.json').read_text());cores=json.loads((R/'family-cores.json').read_text())
checks={}
for k,ns in {'ta':['ta_kannada','ta_kannada.base','ti_kannada','te_kannada','t_kannada'],'va':['va_kannada','va_kannada.base','vi_kannada','ve_kannada','vu_kannada','vuu_kannada','vo_kannada','v_kannada','ma_kannada','mi_kannada','ma_kannada.base','me_kannada','mo_kannada','m_kannada']}.items():
 for n in ns:
  if k=='va':
   assert all(any(q[:len(p)-39]==p[:-39] for q in paths[n]) for p in cores[k]),('Va bowl changed',n)
  else:assert all(p in paths[n] for p in cores[k]),('Old core remains',k,n)
 checks[k]={'shared_body_verified_in':ns,'result':'passed'}
signs=['','ಾ','ಿ','ೀ','ು','ೂ','ೃ','ೄ','ೆ','ೇ','ೈ','ೊ','ೋ','ೌ','ಂ','ಃ','್']
consonants=[chr(c) for c in range(0xc95,0xcba) if c in TTFont(O/'BVMatanga-Regular.ttf').getBestCmap()]
corpus=set(c+v for c in ['ತ','ವ'] for v in signs)
for c in consonants:
 for t in ['ತ','ವ']:
  for v in signs:
   corpus.add(c+'್'+t+v);corpus.add(t+'್'+c+v)
corpus.update(['ತ್ತೈ','ತ್ತೃ','ತ್ತ್ಯ','ವ್ತೈ','ವ್ತೃ','ವ್ತ್ಯ','ಸ್ವಾತಂತ್ರ್ಯ','ಮಾತೃತ್ವ','ವೃತ್ತಿ','ತತ್ವ','ವಿವೇಕ','ವೈವಿಧ್ಯ','ಮತಂಗೇಶ್ವರ'])
base=Renderer(R/'source/NotoThin.ttf')
for style in ['Regular','Bold']:
 rr=Renderer(O/f'BVMatanga-{style}.ttf');prev=Renderer(R/'previous-v1.1'/f'BVMatanga-{style}.ttf')
 for s in corpus:
  new=[a.codepoint for a,b in rr.shape(s)];old=[a.codepoint for a,b in base.shape(s)]
  assert new==old and 0 not in new,s
  im=rr.text(s,96);assert im.width>0 and im.height>0
 # The approved standalone ta is preserved exactly, including its raster.
 a=rr.text('ತ',600);b=prev.text('ತ',600)
 assert a.size==b.size and a.tobytes()==b.tobytes(),'Standalone ta changed'
 changed=[]
 for n in rr.font.getGlyphOrder():
  if rr.font['glyf'][n].compile(rr.font['glyf'])!=prev.font['glyf'][n].compile(prev.font['glyf']):changed.append(n)
 checks[style]={'targeted_shaping_and_rendering_cases':len(corpus),'standalone_ta_pixel_identical_to_approved_revision':True,'changed_glyphs':changed,'stroke_width_design_units':32 if style=='Regular' else 46}
report=O/'Validation-Report.json';d=json.loads(report.read_text());d['family_revision_checks']=checks;d['additional_references']=['Letter-Ta-Reference.jpg','Letter-Va-Reference.png'];d['limitations']=[s.replace('first release','revised release') for s in d['limitations']];report.write_text(json.dumps(d,ensure_ascii=False,indent=2));print(json.dumps(checks,ensure_ascii=False,indent=2))
