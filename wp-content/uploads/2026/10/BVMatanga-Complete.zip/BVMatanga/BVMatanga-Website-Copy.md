# BVMatanga

## Suggested headline
Kannada lettering with the character of stone and the presence of line art.

## Short description
BVMatanga is an inscription-inspired Kannada display font with flowing curves, rounded strokes and four built-in illustrated symbols. Available in Regular and Bold, it brings lettering and imagery together for cultural programmes, invitations, book covers and devotional designs.

## Website feature text
BVMatanga began with a Kannada rock inscription reading “ಮತಂಗೇಶ್ವರ” and “ದೇವರದಿಡ್ಡಿ”. Its broad curves, open forms and distinctive strokes became the starting point for a contemporary display typeface. Selected letters were redrawn from the supplied references, and the design was extended across a working Kannada font with vowel signs, conjunct components and numerals.

The family’s signature feature is its collection of four illustrated glyphs: an emblem, an elephant with a veena, Matangi, and a standing Matanga with the surrounding landscape. These illustrations are embedded as scalable font outlines. They can be inserted as characters, resized and coloured with the text tools in compatible design applications.

Regular and Bold offer two lettering weights. The detailed symbol artwork is deliberately identical in both styles, preserving the fine lines and small interior details of the supplied drawings. Use the font for expressive titles and the illustrations as larger decorative features.

## Feature highlights
- Kannada display lettering inspired by the supplied rock-inscription reference.
- Broad bowls, open joins, rounded strokes and sweeping upper forms.
- Revised ತ and ವ families, including the corrected ವಾ join.
- Regular and Bold, with standard Unicode Kannada input and OpenType shaping.
- Four built-in outline illustrations on dedicated Private Use Area codes.
- 704 glyphs per style and 449 mapped Unicode characters, including 91 Kannada-block codepoints and four private-use symbols.
- TTF files for installation, WOFF2 files for websites, and separate SVG symbol artwork.
- A visual symbol guide with copy buttons and an exact character-code reference.

## Suggested tagline
Letters rooted in an inscription. Illustrations built into the font.

## Accurate provenance and use notes
BVMatanga is an inscription-inspired interpretation, not a complete historical facsimile. The reference contains only a small part of the alphabet; other letterforms are extrapolated. It is derived from Noto Serif Kannada and retains its Kannada shaping infrastructure. Credit that derivation in detailed font information.

The four illustrations are traced from user-supplied drawings. They are custom private-use symbols, not newly assigned standard Unicode characters. They display correctly only when BVMatanga is applied. Do not claim that these symbol designs are historically authenticated or exclusive to this font.

Use the detailed illustrations at display sizes. The full standing scene is intended for large decorative use, not a tiny inline icon. This release has passed automated shaping and rasterization checks; typography should still be proofread in the intended application.

The font is distributed under the SIL Open Font License 1.1. Keep the included OFL.txt with redistributed font files. Follow its terms for modification and redistribution; font files must not be sold by themselves. See OFL.txt for the complete terms. The license notice does not establish independent provenance for the supplied artwork.
