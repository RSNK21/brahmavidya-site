﻿Brahmavidya Kannada Word Add-in 2.0.4
=====================================

Converts Kannada between Nudi / Baraha (legacy ASCII) and Unicode inside Microsoft Word.
Works offline. Windows 10 or 11, Word 2010 to Microsoft 365, 32-bit or 64-bit.

Install
1. Close every Word window.
2. Double-click BV_Kannada_Word_AddIn.exe and press Install.
   Windows then asks once for permission to register the add-in for this computer;
   allow it (Microsoft 365 Word loads the add-in most reliably that way).
   If Windows shows "Windows protected your PC", choose More info, then Run anyway
   (the program is not commercially code-signed).
3. Open Word. A new tab, Brahmavidya Kannada, is on the ribbon.

Use
- Select text and press "Nudi to Unicode" or "Unicode to Nudi".
- Press with nothing selected to convert the whole document, including headers,
  footers, footnotes and text boxes. In a whole document only text set in a Nudi or
  Baraha font is converted, so English is never touched.
- Bold, italics, sizes, colours, footnotes, fields and pictures are kept.
- Choose the font for converted text from the two lists on the tab.
- Ctrl+Z undoes a conversion in one step.

If the tab does not appear
Run the same program and press Check. It tests the installation and shows a short
report; press Copy report and send it to Brahmavidya.

Remove
Run the same program and press Remove, or use: BV_Kannada_Word_AddIn.exe /uninstall

What's new in 2.0
- The new Brahmavidya conversion engine, the same one as on brahmavidya.co.in.
  Fixes stacked ottaksharas, arkavattu, the u-sign of pa, the vocalic-r sign after an ottu and more.
- Formatting is kept: conversion goes run by run instead of retyping the selection.
- Whole-document conversion, font choice, Kannada numerals option.

Brahmavidya, Mysuru . https://brahmavidya.co.in/kannada-ascii-to-unicode-converter/
